// Question Array

const questions = [

    {

        questions: "What is the capital of France?",

        Options: ["Berlin", "Madrid", "Paris", "Rome"],

        answer: "Paris",

    },

    {

        questions: "Which language runs in a web browser?",

        options: ["java", "c", "Python", "Javascript"],

        answer: "Javascript",

    },

    {

        questions: "What does CSS stand for ?",

        options: [

            "Cascadind style sheets",

            "Central style sheets",

            "Cascading Simple Sheets",

            "Cars SUVs Sailboats",

        ],

        answer: "cascading style sheets",

    },

];

let currentQuestionIndex = 0;

let score = 0;

//DOM elements

const questionE1 = document.getElementById("question");

const optionsE1 = document.getElementById("options");

const feedbackE1 = document.getElementById("feedback");

const nextBtn = document.getElementById("next-btn");

const scoreE1 = document.getElementById("score");

// Load Question

function load() {

    const currentQuestion = questions[currentQuestionIndex];

    questionE1.textcontent = currentQuestion.questions;

    optionsE1.innerHTML = "";

    feedbackE1.textcontent = "";

    currentQuestion.options.forEach((option) => {

        const button = document.createElement("button");

        button.textContent = option;

        button.addEventListener("click", () => selectAnswer(option));

        optionsE1.appendChild(button);

    });

}

// Select Answer

function selectAnswer(selected) {

    const currentQuestion = questions[currentQuestionIndex];

    if (selected === currentQuestion.answer) {

        feedbackE1.textContent = "Correct!";

        feedbackE1.style.color = "green";

        score++;

    } else {

        feedbackE1edbackEl.textContent = 'Wrong! The correct answer is ${currentQuestion.answer}.';

        feedbackE1dbackEl.style.color = "red";

    }

    scoreE1.textContent = 'Score: ${score}';

    disableOptions();

}

// Disable Options

function disableOptions() {

    const buttons = optionsE1.querySelectorAll("button");

    buttons.forEach((button) => (button.disabled = true));

}

// Next Question

nextBtn.addEventListener("click", () => {

    currentQuestionIndex++;

    if (currentQuestionIndex < questions.length) {

        loadQuestion();

    } else {

        endQuiz();

    }

});

// End Quiz

function endQuiz() {

    questionE1.textContent = "Quiz Completed!";

    optionsE1.innerHTML = "";

    feedbackE1.textContent = 'Final Score: ${score}';

  nextBtn.style.display = "none";

}

//start Quiz

loadQuestion();